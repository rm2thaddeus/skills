"""
excel_operations.py
--------------------

This module provides utility functions for reading tabular data from CSV files
and writing Excel workbooks with formulas using the `openpyxl` library.  It is
intended to demonstrate how Python can automate common spreadsheet tasks
without relying on Excel macros or VBA.  In particular, the function
`create_workbook_with_formulas` takes a CSV file of sample data, writes it to a
worksheet, and inserts an ``AVERAGE`` formula for each row to compute the mean
of numeric columns.  This mirrors the example shown in the Analytics Vidhya
guide【774348477218590†L387-L399】 and Real Python tutorial【753142762656788†L1118-L1164】.

Usage from the command line:

```bash
python -m scripts.excel_operations
```

This will read ``data/sample_input.csv`` and produce ``output.xlsx`` in the
project root.  You can adjust the input and output paths via command‑line
arguments.
"""

import csv
import os
from typing import List, Sequence, Optional

from openpyxl import Workbook, load_workbook


def read_csv_data(csv_path: str) -> List[List[str]]:
    """Read tabular data from a CSV file.

    The function returns a list of rows, where each row is a list of
    string values.  Blank lines are ignored.  If the file does not
    exist, a ``FileNotFoundError`` is raised.

    Parameters
    ----------
    csv_path : str
        Path to the CSV file.

    Returns
    -------
    List[List[str]]
        The rows of the CSV file.
    """
    data: List[List[str]] = []
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        for row in reader:
            # Skip completely empty rows
            if any(cell.strip() for cell in row):
                data.append(row)
    return data


def create_workbook_with_formulas(
    data: Sequence[Sequence[str]],
    header: Optional[Sequence[str]] = None,
    output_path: str = "output.xlsx",
) -> Workbook:
    """Create an Excel workbook with data and insert average formulas.

    The first column of the input data is assumed to be a non‑numeric label
    (e.g. a name).  All subsequent columns are treated as numeric values
    represented as strings.  For each row in the dataset, an ``AVERAGE``
    formula is inserted into the cell immediately to the right of the last
    numeric column.  The formula computes the average across the numeric
    columns for that row, using the ``AVERAGE`` Excel function.  This
    method matches the pattern described in the tutorial on automating Excel
    with openpyxl【774348477218590†L387-L399】.

    Parameters
    ----------
    data : Sequence[Sequence[str]]
        A 2‑dimensional array of values (list of rows).  Each row must
        have at least one element.
    header : Optional[Sequence[str]], optional
        Optional header names to write into the first row of the worksheet.
        If provided, the header must have one element more than the number
        of numeric columns in the data, because a new "Average" column
        will be appended.
    output_path : str, optional
        The location where the resulting workbook should be saved.

    Returns
    -------
    openpyxl.Workbook
        The workbook object with formulas inserted.
    """
    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"

    # Write header if provided
    if header is not None:
        # Append an extra column for the computed average
        ws.append(list(header))

    for idx, row in enumerate(data, start=1 if header is None else 2):
        # Write the row values to the worksheet
        ws.append(list(row))
        # Determine the Excel coordinate for the average formula
        # Assume first column is non‑numeric; numeric columns start at B
        num_cols = len(row) - 1
        if num_cols > 0:
            # Index of the row we just appended (1‑based).  openpyxl
            # automatically appends rows sequentially, so the current row
            # number is ws.max_row
            excel_row_num = ws.max_row
            # Column letters: numeric values from column 2 to column (num_cols+1)
            # openpyxl uses 1‑based indexing; A=1, B=2, etc.
            start_col_letter = chr(ord('A') + 1)  # 'B'
            # Compute letter of the last numeric column
            end_col_letter = chr(ord('A') + num_cols)
            # Column letter for the formula cell is one after the last numeric column
            formula_col_letter = chr(ord('A') + num_cols + 1)
            # Construct the Excel formula string
            formula = f"=AVERAGE({start_col_letter}{excel_row_num}:{end_col_letter}{excel_row_num})"
            # Write the formula to the next cell
            ws[f"{formula_col_letter}{excel_row_num}"] = formula

    # Save the workbook
    wb.save(output_path)
    return wb


def main(args: Optional[Sequence[str]] = None) -> None:
    """Entry point for command‑line execution.

    Reads data from a CSV file located in the ``data`` folder (``sample_input.csv``),
    then calls :func:`create_workbook_with_formulas` to create an Excel file
    containing the data and corresponding average formulas.  The resulting
    workbook is saved as ``output.xlsx`` in the project root.
    """
    import argparse

    parser = argparse.ArgumentParser(description="Create an Excel workbook with average formulas.")
    parser.add_argument(
        "csv_path",
        nargs="?",
        default=os.path.join(os.path.dirname(__file__), "..", "data", "sample_input.csv"),
        help="Path to the input CSV file. Defaults to 'data/sample_input.csv'.",
    )
    parser.add_argument(
        "output_path",
        nargs="?",
        default=os.path.join(os.path.dirname(__file__), "..", "output.xlsx"),
        help="Output Excel file. Defaults to 'output.xlsx' in the repository root.",
    )
    ns = parser.parse_args(args)

    data = read_csv_data(ns.csv_path)
    # Create a header row: first column is label, next columns are numeric values, plus an Average column
    if data:
        num_numeric_cols = len(data[0]) - 1
    else:
        num_numeric_cols = 0
    header = ["Label"] + [f"Value {i}" for i in range(1, num_numeric_cols + 1)] + ["Average"]
    create_workbook_with_formulas(data, header=header, output_path=ns.output_path)
    print(f"Workbook with formulas saved to {ns.output_path}")


if __name__ == "__main__":  # pragma: no cover
    main()