# Excel Automation with Python and AI

This repository demonstrates how to automate common Excel tasks using Python, open‑source libraries, and emerging AI tools.  It is designed as a starting point for analytics teams that want to reduce manual effort, enforce data quality, and integrate Excel into modern data pipelines.

## Motivation

Many large analytics teams still rely on spreadsheets to deliver insights to business users.  At the same time, they need to ingest data from multiple sources, transform it, perform statistical analysis, and communicate results in PowerPoint or other presentation formats.  Manual spreadsheet manipulation is slow and error‑prone.  Modern practices recommend treating data as a product【985977676661186†L200-L252】 and building pipelines that include ingestion, transformation, analysis, insight generation and delivery【464180270019344†L118-L286】.  Python tools like `pandas`, `openpyxl` and `python‑pptx` help automate these steps, while AI features in Excel such as Copilot can assist with data cleaning, trend identification, and formula generation【8466497491016†L160-L184】.

## Repository Overview

The project contains modular Python code and tests that illustrate how to:

* Create an Excel workbook from data and insert working formulas using the `openpyxl` library.  The ability to add formulas programmatically allows you to replicate spreadsheet calculations reliably and at scale【774348477218590†L387-L399】【753142762656788†L1118-L1164】.
* Read and modify existing Excel workbooks without resorting to VBA or macros.  Using Python you can update cell values, merge or unmerge cells, insert charts and images, and apply styling【774348477218590†L403-L527】.
* Demonstrate how tests can verify that Excel formulas are inserted correctly.  Tests use `pytest` to load the workbook and confirm that formulas match expected strings.

Although not implemented in this skeleton, the repository structure leaves room for future enhancements such as integrating AI suggestions from Microsoft Copilot for Excel to clean data, suggest formulas, and generate reports【8466497491016†L160-L200】.  You can also add scripts to generate PowerPoint presentations using `python‑pptx` and feed outputs into business workflows.

## Structure

```
excel_automation/
├── README.md                 # This file
├── requirements.txt          # Python dependencies
├── scripts/
│   ├── __init__.py
│   ├── excel_operations.py   # Library functions for working with Excel
│   └── generate_report.py    # Placeholder for future report or PPT generation
├── tests/
│   └── test_excel_operations.py  # Tests verifying formula insertion
└── data/
    └── sample_input.csv      # Sample tabular data used in the example
```

## Getting Started

1. **Install dependencies**

   Create a virtual environment and install the required packages.  The `requirements.txt` lists `openpyxl` and `pytest` as dependencies.

   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```

2. **Run the sample script**

   The `excel_operations.py` module exposes a function `create_workbook_with_formulas` that reads CSV data from the `data` directory, creates an Excel file, and inserts an average formula for each row.  To run the script and generate `output.xlsx` in the project root:

   ```bash
   python -m scripts.excel_operations
   ```

3. **Run tests**

   To verify that formulas are inserted correctly, run `pytest` from the project root:

   ```bash
   pytest -q
   ```

## Extending the Repository

Here are a few ideas for how you can build on this skeleton:

* **Connect to data warehouses.**  Large analytics teams usually ingest data from operational databases or APIs before transforming it【464180270019344†L118-L146】.  You can use Python libraries (e.g. `sqlalchemy`, `requests`) to fetch data and write it into Excel files.
* **Automate dashboards and reports.**  The `generate_report.py` file can be expanded to use `python‑pptx` or `matplotlib` to generate PowerPoint slides or PDF reports from your Excel data.
* **Incorporate AI suggestions.**  Microsoft’s Copilot in Excel can automatically clean data, identify trends, suggest complex formulas, and create reports【8466497491016†L160-L200】.  Future integration could call the Copilot API (when available) to automate these tasks directly from Python.
* **Adopt DataOps practices.**  Use this repository as a seed for a CI/CD pipeline that automatically runs tests and deploys updated Excel templates.  Embrace a data product mindset by collecting requirements from data consumers before building new workbooks【985977676661186†L214-L253】.

## Acknowledgements

This repository draws on best practices from modern data engineering, which emphasize data ingestion, transformation, analysis, insight generation, and delivery【464180270019344†L118-L286】.  It also demonstrates how to use the `openpyxl` library to add formulas programmatically【774348477218590†L387-L399】【753142762656788†L1118-L1164】 and highlights the emerging AI features in Excel that can further streamline workflows【8466497491016†L160-L200】.