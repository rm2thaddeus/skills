"""
Test suite for excel_operations.

These tests use the sample data in ``data/sample_input.csv`` to ensure that
formulas are inserted correctly by the ``create_workbook_with_formulas`` function.
It verifies that each row has an ``AVERAGE`` formula referencing the numeric
columns and that the header row includes an "Average" column.  The tests use
``pytest`` fixtures to work with temporary files.
"""

import os
import tempfile
from pathlib import Path

import pytest
from openpyxl import load_workbook

from scripts.excel_operations import read_csv_data, create_workbook_with_formulas


@pytest.fixture(scope="module")
def sample_data_path() -> Path:
    """Return the path to the sample CSV file shipped with the repository."""
    return Path(os.path.dirname(__file__)).parent / "data" / "sample_input.csv"


def test_create_workbook_with_formulas_creates_average_column(tmp_path: Path, sample_data_path: Path) -> None:
    """Ensure the generated workbook contains an average formula for each row."""
    # Read sample data from CSV
    data = read_csv_data(str(sample_data_path))
    # Determine header based on number of numeric columns
    num_numeric_cols = len(data[0]) - 1
    header = ["Label"] + [f"Value {i}" for i in range(1, num_numeric_cols + 1)] + ["Average"]
    # Create workbook in a temporary location
    output_excel = tmp_path / "test_output.xlsx"
    create_workbook_with_formulas(data, header=header, output_path=str(output_excel))
    # Load workbook and verify formulas
    wb = load_workbook(output_excel, data_only=False)
    ws = wb.active
    # Verify header row ends with "Average"
    assert ws[1][len(header) - 1].value == "Average", "Last header column should be 'Average'"
    # For each data row check the formula
    for i, row in enumerate(data, start=2):  # 1-based row index, with header at row 1
        # Build expected formula; numeric columns from B to last numeric column letter
        start_col_letter = "B"
        # Last numeric column: 1 label + num_numeric_cols numeric => column index = num_numeric_cols + 1 (1-based)
        # Convert column index to letter: A=1, B=2, etc.
        end_col_letter = chr(ord('A') + num_numeric_cols)
        expected_formula = f"=AVERAGE({start_col_letter}{i}:{end_col_letter}{i})"
        # Formula cell is one column after the last numeric column
        formula_col_letter = chr(ord('A') + num_numeric_cols + 1)
        cell_value = ws[f"{formula_col_letter}{i}"].value
        assert cell_value == expected_formula, f"Row {i} formula mismatch: {cell_value} != {expected_formula}"